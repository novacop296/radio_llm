# Experiment Bundle: bundle_test_01

**Experiment ID**: exp_bench_test_01
**Model ID**: model_txrv_dense121
**Created**: 2026-09-24T02:25:06.786391+00:00

## Safety Disclaimer
RESEARCH PROTOTYPE — NOT CLINICAL PERFORMANCE EVIDENCE. Portable experiment bundles are self-contained artifacts for academic reproducibility, code auditing, and benchmark verification only.

## Contents
- `model/metadata.json`: Model architecture and weight identity.
- `dataset/metadata.json`: Cohort dataset version and study count.
- `experiment/config.json`: Canonical experiment configuration parameters.
- `evaluation/metrics.json`: Classification and agreement metrics.
- `provenance/audit_trail.json`: Complete audit stages.
- `scripts/reproduce.py`: Air-gapped validation script.
